﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadWcfTraceLog
{
    public interface ITracingTables
    {
        IEnumerable<Trace> QueryTraceTable(DataTable dtTraceData, DataTable dtDataItem, DataTable dtTraceRecord, DataTable dtExtendedData, DataTable dtSystemDiagnostics);
        IEnumerable<Trace> QueryTraceTable(DataTable dtTraceData, DataTable dtDataItem, DataTable dtTraceRecord, DataTable dtExtendedData, DataTable dtSystemDiagnostics, DataTable dtaddtional, string column);
    }
}
