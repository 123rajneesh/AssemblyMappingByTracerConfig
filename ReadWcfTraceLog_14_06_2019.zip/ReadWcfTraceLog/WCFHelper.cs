﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadWcfTraceLog
{
    public class WCFHelper
    {
        private static string TRIM_KEYWORD_AT = "at";

        private static string SKIP_KEYWORD = "System";

        private static string INDEXOF_IN = " in ";

        private static string WCF_SERVICE_EXTENSTION = ".svc";

        private static string[] CONSTRUCTORS = { ".ctor()", "..ctor()" };

        private static string NAMESPACEEXPRESSION = @"xmlns(:\w+)?=""([^""]+)""|xsi(:\w+)?=""([^""]+)""";

        private static string COLONATTRIBUTES = @"d4p1(:\w+)?=""([^""]+)""|xsi(:\w+)?=""([^""]+)""";

        public static string ReadCallStack(string callStack, ServiceInfoType serviceInfoType)
        {
            try
            {
                string value = string.Empty;
                using (StringReader reader = new StringReader(callStack))
                {
                    while (true)
                    {
                        var line = reader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        //skip systems types calls
                        line = line.TrimStart(' ');

                        var nsline = line.TrimStart(TRIM_KEYWORD_AT.ToCharArray()).TrimStart(' ');

                        if (!nsline.StartsWith(SKIP_KEYWORD))
                        {
                            var indexOfin = nsline.IndexOf(INDEXOF_IN);

                            switch (serviceInfoType)
                            {
                                case ServiceInfoType.ContractInfo:
                                    if (indexOfin == -1)
                                    {
                                        return GetContract(nsline);
                                    }
                                    break;
                                case ServiceInfoType.ServiceMethodInfo:
                                    if (indexOfin == -1)
                                    {
                                        value = nsline.Trim();
                                        return value;
                                    }
                                    break;
                            }
                        }
                    }
                    return value;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static string GetContract(string nsline)
        {
            string contract = string.Empty;
            try
            {
                var line = nsline.Trim();
                var lastIndexOf_Dot = line.LastIndexOf('.');

                if (line.Contains('('))
                {
                    var fullName = line.Substring(0, lastIndexOf_Dot);

                    var fullNameIdx = fullName.LastIndexOf('.') + 1;

                    contract = line.Substring(fullNameIdx, fullName.Length - fullNameIdx);
                }
                else
                {
                    contract = line.Substring(lastIndexOf_Dot, line.Length - lastIndexOf_Dot).Trim('.');
                }
                return contract;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static string GetBinding(string serviceUrl)
        {
            Uri uri = new Uri(serviceUrl);
            //string requested = uri.Scheme + Uri.SchemeDelimiter + uri.Host + ":" + uri.Port;
            string protocol = uri.Scheme;

            string binding = string.Empty;

            foreach (var bb in DefaultBinding.Bindings)
            {
                foreach (var v in bb.Value)
                {
                    if (v == protocol)
                    {
                        binding = bb.Key;
                        return binding;
                    }

                }
            }
            return binding;
        }

        public static string GetMethod(string callStack, string contract)
        {
            string[] methods = callStack.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries).ToArray();

            //remove methods wich have contract
            string[] NoneContractMethods = methods.Where(x => !x.Contains(contract)).Reverse().ToArray();

            if (NoneContractMethods.Count() > 1)
            {
                NoneContractMethods = NoneContractMethods.Skip(1).ToArray();
            }

            return NoneContractMethods.FirstOrDefault();
        }

        public static string ReadCallStackForAllMethods(string callStack)
        {
            try
            {
                IList<string> linecol = new List<string>();
                string value = string.Empty;
                using (StringReader reader = new StringReader(callStack))
                {
                    while (true)
                    {
                        var line = reader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        //skip systems types calls
                        line = line.TrimStart(' ');
                        line = line.TrimStart(TRIM_KEYWORD_AT.ToCharArray()).TrimStart(' ');

                        string newlines = RemoveLinesStartWith(SKIP_KEYWORD, line);


                        if (!string.IsNullOrEmpty(newlines))
                        {
                            linecol.Add(newlines);
                        }

                    }
                    string joined = string.Join("|", linecol);
                    return joined;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static string RemoveLinesStartWith(string v, string line)
        {
            string methdline = string.Empty;

            if (!line.StartsWith(v))
            {
                var indexOfin = line.IndexOf(INDEXOF_IN);

                if (indexOfin > -1)
                {
                    line = line.Substring(0, indexOfin).Trim();

                    //if (!CONSTRUCTORS.Contains(line))
                    //    return line;
                    if (!line.Contains(".ctor()") || line.Contains("..ctor()"))
                        return line;
                }
                return line;
            }
            return null;
        }

        public static string RemoveColonAttributesFromXml(string content)
        {
            if (!string.IsNullOrEmpty(content))
            {
                content = System.Text.RegularExpressions.Regex.Replace(content, COLONATTRIBUTES, string.Empty);
            }
            return content;
        }

        public static string RemoveNamespaceAttributesFromXml(string content)
        {
            if (!string.IsNullOrEmpty(content))
            {
                content = System.Text.RegularExpressions.Regex.Replace(content, NAMESPACEEXPRESSION, string.Empty);
            }
            return content;
        }

        public static bool FilterAddressByExtension(string address)
        {
            if (!string.IsNullOrEmpty(address))
                return address.ToLower().Contains(WCF_SERVICE_EXTENSTION);
            return false;
        }



    }
}
