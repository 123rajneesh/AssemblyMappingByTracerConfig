﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadWcfTraceLog
{
    public class CallStack
    {
        private static string TRIM_KEYWORD_AT = "at";

        private static string SKIP_KEYWORD = "System";

        private static string INDEXOF_IN = " in ";

        private static string txtxpath = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ReadWcfTraceLog\proxyCallStack.txt";
        //public static List<string> Methods()
        //{
        //    string text = File.ReadAllText(txtxpath).ToString();

        //    var result = ReadCallStack(text, isProxy: true);
        //    return null;
        //}

        public static List<string> ReadCallStack(string callStack, bool isProxy = false)
        {
            try
            {
                List<string> linecol = new List<string>();
                string value = string.Empty;
                using (StringReader reader = new StringReader(callStack))
                {
                    while (true)
                    {
                        var line = reader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        //skip systems types calls
                        line = line.TrimStart(' ');
                        line = line.TrimStart(TRIM_KEYWORD_AT.ToCharArray()).TrimStart(' ');
                        string newlines = RemoveLinesStartWith(SKIP_KEYWORD, line);

                        if (!string.IsNullOrEmpty(newlines))
                        {
                            linecol.Add(newlines);
                        }

                    }
                    return linecol;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static string RemoveLinesStartWith(string v, string line)
        {
            string methdline = string.Empty;
            if (!line.StartsWith(v))
            {
                var indexOfin = line.IndexOf(INDEXOF_IN);
                if (indexOfin > -1)
                {
                    line = line.Substring(0, indexOfin).Trim();
                    if (!line.Contains("ctor()"))
                        return null;
                }
                methdline = line;
            }
            return methdline;
        }
    }
}
