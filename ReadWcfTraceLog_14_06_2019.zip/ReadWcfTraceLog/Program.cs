﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace ReadWcfTraceLog
{
    class Program
    {
        private static string activityLog = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\Web\bin\Release\Publish\TracesByActivity.svclog";

        private static string WebLog = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\Web\bin\Release\Publish\Traces.svclog";

        private static string exeLog = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\bin\Debug\Traces.svclog";

        static void Main(string[] args)
        {

            //CallStack.Methods();

            //ActivityNodes();
            //Console.Read();
            string svcCallLogFile = File.ReadAllText(exeLog);

            //Added WCF Consumer DTO
            var DTOs = ConsumerLogReader.GetDataFromTracingTables(svcCallLogFile);
        }

        static void ActivityNodes()
        {

            XmlDocument xDoc = new XmlDocument();
            // Load Xml
            string svcCallLogFile = File.ReadAllText(WebLog).ToString();

            string filter = @"xmlns(:\w+)?=""([^""]+)""|xsi(:\w+)?=""([^""]+)""";
            svcCallLogFile = "<root>" + Regex.Replace(svcCallLogFile, filter, "") + "</root>";

            xDoc.LoadXml(svcCallLogFile);
            //XmlNodeList nodes = xDoc.SelectNodes("//root//E2ETraceEvent//System//Correlation[@ActivityID='{35a833fb-e25e-459a-87aa-f7bf373e3c2d}']");
            List<string> logActivity = new List<string>();
            XmlNodeList nodes = xDoc.SelectNodes("//System/Correlation[@ActivityID='{35a833fb-e25e-459a-87aa-f7bf373e3c2d}']");
            foreach (XmlNode node in nodes)
            {
                logActivity.Add(node.ParentNode.ParentNode.OuterXml);
                //Fetch the Node and Attribute values.
                //Console.WriteLine("Correlation: " + node["Correlation"].InnerText + " ActivityID: " + node.Attributes["ActivityID"].Value);
            }
        }
    }
}
