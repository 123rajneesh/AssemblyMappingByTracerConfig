﻿using ReadWcfTraceLog.Properties;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ReadWcfTraceLog
{
    public class ConsumerLogReader
    {
        public static List<Trace> GetDataFromTracingTables(string content)
        {
            try
            {
                var dsCollection = ReadTraceContentToDataset(content);

                List<Trace> traceCollection = null;
                if (dsCollection != null)
                {
                    if (dsCollection.Count > 0)
                    {
                        ITracingTables tracingTables = new TracingTables();
                        traceCollection = new List<Trace>();

                        foreach (var ds in dsCollection)
                        {
                            List<Trace> traceDTO = null;
                            //used for http data mapping
                            var dtApplicationData = ds.Tables["ApplicationData"];
                            var dtTraceData = ds.Tables["TraceData"];
                            var dtDataItem = ds.Tables["DataItem"];
                            var dtTraceRecord = ds.Tables["TraceRecord"];
                            var dtExtendedData = ds.Tables["ExtendedData"];
                            var dtMessageProperties = ds.Tables["MessageProperties"];
                            var dtSystemDiagnostics = ds.Tables["System.Diagnostics"];
                            var dtEndpointReference = ds.Tables["EndpointReference"];

                            switch (ds.DataSetName)
                            {
                                case BindingImplementation.HttpBinding:

                                    var httpDTO = tracingTables.QueryTraceTable(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics, dtMessageProperties, "Via").Distinct().ToList();
                                    traceDTO = GroupDTO(httpDTO, BindingImplementation.Unkown);
                                    break;

                                case BindingImplementation.NetTcpBinding:

                                    var netTcpDTO = tracingTables.QueryTraceTable(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics, dtEndpointReference, "Address").Distinct().ToList();
                                    traceDTO = GroupDTO(netTcpDTO, BindingImplementation.Unkown);
                                    break;
                                case BindingImplementation.ClientProxy:

                                    //proxy do not have consumer method
                                    var proxydto = tracingTables.QueryTraceTable(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics).Distinct().ToList();
                                    traceDTO = GroupDTO(proxydto, BindingImplementation.ClientProxy);

                                    break;
                            }
                            if (traceDTO != null)
                                traceCollection.AddRange(traceDTO);

                        }

                        var proxy = UpdateProxyDTOForMethod(traceCollection);
                        traceCollection.Clear();
                        traceCollection.AddRange(proxy);
                    }
                }
                return traceCollection;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static List<Trace> GroupDTO(List<Trace> traceDTO, string BindingImplementation)
        {
            return traceDTO.GroupBy(g => new
            {
                g.Address,
                g.Binding,
                g.Contract,
                g.CallStack
            })
               .Select(ac => new Trace
               {
                   Address = ac.Key.Address,
                   Binding = ac.Key.Binding,
                   Contract = ac.Key.Contract,
                   CallStack = ac.Key.CallStack,
                   BindingImplementation = BindingImplementation


               }).ToList();
        }

        private static List<Trace> UpdateProxyDTOForMethod(List<Trace> diagnosticsAttribute)
        {
            var isProxyDto = diagnosticsAttribute.Where(x => x.BindingImplementation == BindingImplementation.ClientProxy).ToList();

            var isUnknownDto = diagnosticsAttribute.Where(x => x.BindingImplementation == BindingImplementation.Unkown).ToList();

            List<Trace> proxyDTO = new List<Trace>();

            //If proxy Find
            if (isProxyDto.Count > 0)
            {
                foreach (var p in isProxyDto)
                {
                    var temp2 = isUnknownDto.Where(u => u.Contract.ToLower() == p.Contract.ToLower() && u.Binding.ToLower() == p.Binding.ToLower() && u.Address.ToLower() == p.Address.ToLower()).ToList();

                    foreach (var t in temp2)
                    {
                        Trace trace = new Trace();

                        trace.Address = p.Address;

                        trace.Binding = p.Binding;

                        trace.Contract = p.Contract;

                        trace.ConsumerMethodSig = WCFHelper.GetMethod(t.CallStack, p.Contract);

                        proxyDTO.Add(trace);
                    }
                }
            }
            else
            {
                foreach (var t in isUnknownDto)
                {
                    Trace trace = new Trace();

                    trace.Address = t.Address;

                    trace.Binding = t.Binding;

                    trace.Contract = t.Contract;

                    trace.ConsumerMethodSig = WCFHelper.GetMethod(t.CallStack, t.Contract);

                    proxyDTO.Add(trace);
                }
            }
            return proxyDTO;
        }

        private static List<DataSet> ReadTraceContentToDataset(string content)
        {
            try
            {
                List<DataSet> dsCollection = null;

                if (!string.IsNullOrEmpty(content))
                {
                    dsCollection = new List<DataSet>();

                    content = WCFHelper.RemoveNamespaceAttributesFromXml(content);

                    content = WCFHelper.RemoveColonAttributesFromXml(content);

                    //http protocol channelfactory used schema
                    var dshttpTrace = ReadLog(content, Resources.DataSet_Http_Schema, BindingImplementation.HttpBinding);

                    // tcp protocol channelfactory used schema
                    var dsnetTcpTrace = ReadLog(content, Resources.DataSet_NetTcp_Schema, BindingImplementation.NetTcpBinding);

                    // client proxy channelfactory used schema
                    var dsProxyTrace = ReadLog(content, Resources.DataSet_Proxy_Schema, BindingImplementation.ClientProxy);

                    dsCollection.Add(dshttpTrace);

                    dsCollection.Add(dsnetTcpTrace);

                    dsCollection.Add(dsProxyTrace);
                }

                return dsCollection;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static DataSet ReadLog(string logFileContent, string datasetSchema, string binding)
        {
            DataSet ds = new DataSet();

            //Setting to read all root elements
            XmlReaderSettings settings = new XmlReaderSettings();

            settings.ConformanceLevel = ConformanceLevel.Fragment;

            //Invoke the ReadXmlSchema method with the from resourec file object.               
            ds.ReadXmlSchema(new StringReader(datasetSchema));

            XmlReader reader = XmlReader.Create(new StringReader(logFileContent), settings);

            while (reader.Read())
            {
                ds.ReadXml(reader, XmlReadMode.Auto);
            }
            ds.DataSetName = binding;

            return ds;
        }

    }
}
