﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadWcfTraceLog
{
    /*WCF Settings*/
    public enum ServiceInfoType
    {  
        ServiceMethodInfo = 1,
        AddressInfo = 2,
        BindingInfo = 3,
        ContractInfo = 4
    }
    public class DefaultBinding
    {
        public static readonly Dictionary<string, string[]> Bindings = new Dictionary<string, string[]>() {
             { "basichttpbinding", new[] { "http", "https" } },

             { "wshttpbinding", new[] { "http", "https" } },

             { "wsdualhttpbinding", new[] { "http", "https" } },

             { "wsfederationhttpbinding", new[] { "http", "https" } },

             { "nettcpbinding", new[] { "tcp","net.tcp" } },

             { "netnamedpipebinding", new[] { "pipe" } },

             { "netmsmqbinding", new[] { "msmq" } },

             { "netpeertcpbinding", new[] { "p2p" } },

             { "msmqintegrationbinding", new[] { "msmq" } }

        };
    }
}
