﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadWcfTraceLog
{
    public class Trace
    {
        public string BindingImplementation { get; set; }
        public int ApplicationDataId { get; set; }
        public string CallStack { get; set; }
        public string ConsumerMethodSig { get; set; }

        public string Address { get; set; }
        public string Contract { get; set; }
        public string Binding { get; set; }
    }

    public static class BindingImplementation
    {

        public const string HttpBinding = "http";
        public const string NetTcpBinding = "tcp";
        public const string ClientProxy = "ClientProxy";
        public const string Unkown = "Unknown";
    }
}
