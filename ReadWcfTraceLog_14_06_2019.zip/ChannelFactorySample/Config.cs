﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChannelFactorySample
{
    public class Config
    {
        public static string SampleService_httpEndpoint = "http://localhost:61644/Service1.svc";
        public static string SampleService_netTcpEndpoint = "net.tcp://sezt1ff21cc.india.rsystems.com:6296/ServiceContractSample/SampleService.svc/SampleService";

        public static string IWCFAddition_netTcpEndpoint = "net.tcp://sezt1ff21cc.india.rsystems.com:6296/WCFAddition_IIS/Service.svc";

        public static string WCfpeoducerService_httpEndpoint = "http://localhost:62965/WcfProducerSample/Service1.svc";
        public static string ProducerMultipleBindings_IIS = @"net.tcp://sezt1ff21cc.india.rsystems.com:5252/ProducerMultipleBindings_IIS/Service1.svc";

        public static string twcfservicesharedsample = @"http://twcfservicesharedsample.azurewebsites.net/HelloService.svc";
    }
}
