﻿using ChannelFactorySample.NetCalculater;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChannelFactorySample
{
    public class MyMethods
    {
        public static string CalculaterAdd()
        {
            
            ////Using Proxy Client
            CalculaterClient client = new CalculaterClient();

            var output = client.Add(1, 4).ToString();

            return output;

        }
    }
}
