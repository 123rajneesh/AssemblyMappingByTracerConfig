using ChannelFactorySample.NetCalculater;
using Contracts;
using System;
using System.ServiceModel;

namespace ChannelFactorySample
{

    class Program
    {
        static void Main(string[] args)
        {
            //GenericInitializeFactory();          
            donothing();
            //InitializeFactory();
            Console.WriteLine("Executed");
            Console.ReadLine();
        }
        /*
            public static void GenericInitializeFactory()
        {

            // This code is written by an application developer.
            // Create a channel factory.

            BasicHttpBinding myBinding = new BasicHttpBinding();

            EndpointAddress myEndpoint = new EndpointAddress(Config.httpEndpoint);

            ChannelFactory<IService> myChannelFactory = new ChannelFactory<IService>(myBinding, myEndpoint);

            // Create a channel.
            var wcfClient1 = myChannelFactory.CreateChannel();
            var s = wcfClient1.Message();
            Console.WriteLine(s.ToString());
            ((IClientChannel)wcfClient1).Close();

            // Create another channel.
            IService wcfClient2 = myChannelFactory.CreateChannel();
            s = wcfClient2.Message();
            Console.WriteLine(s.ToString());
            ((IClientChannel)wcfClient2).Close();
            myChannelFactory.Close();
        }
             */             
        private static string InitializeFactory()
        {
            var binding = new NetTcpBinding();
            var endpoint = new EndpointAddress(new Uri(Config.ProducerMultipleBindings_IIS));
            var channelFactory = new ChannelFactory<NetCalculater.ICalculater>(binding, endpoint);
            var serviceClient = channelFactory.CreateChannel();
            var result = serviceClient.Add(1, 2);
            channelFactory.Close();


            return result.ToString();
        }
        public static string donothing()
        {
            //var channelFactoryAtmethodLevel = new ChannelFactory<Contracts.IService>(new BasicHttpBinding(), new EndpointAddress(Config.twcfservicesharedsample));
            //var inst = channelFactoryAtmethodLevel.CreateChannel();
            //var output = inst.SyaHello("hello");
            //return output;


            ////Using Proxy Client
            //CalculaterClient client = new CalculaterClient();

            //var output = client.Add(1, 4).ToString();

            //return output;
            MyMethods.CalculaterAdd();
            return null;
        }


    }
}
