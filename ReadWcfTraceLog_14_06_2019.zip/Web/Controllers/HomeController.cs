﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web.producerSample;

namespace Web.Controllers
{
    public class HomeController : Controller
    {
        ServiceClient serviceClient = new ServiceClient();
        // GET: Home
        public ActionResult Index()
        {
            ViewBag.Addition = serviceClient.GoodBye("good bye");
            ViewBag.Addition += " " + serviceClient.Message("Hello");

            return View();
        }

    }
}
