﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TraceConfigInjector
{
    public class WcfXmlNodeBuilder : BaseXMLBuilder
    {
        public static void CheckNAddListeners(XmlDocument doc, XmlElement webConfigData, XmlNodeList ListenerAttr, string innerXML, ref bool isConfigNeedsToAdd, XmlNodeList sourceNodes)
        {
            bool isConfigAdded = false;
            foreach (XmlNode source in sourceNodes[0].ChildNodes)
            {

                if (source.Attributes.GetNamedItem("name").Value == "System.ServiceModel")
                {
                    if (source.ChildNodes.Count > 0)
                    {
                        foreach (XmlNode listner in source.ChildNodes[0])
                        {

                            if (listner.Attributes.GetNamedItem("name").Value == "traceListener")
                            {
                                isConfigAdded = true;
                            }
                            else
                            {
                                isConfigNeedsToAdd = true;
                                XmlElement sorcNode = doc.CreateElement("add");

                                XmlAttribute xmlNameAttribute = doc.CreateAttribute("name");
                                xmlNameAttribute.Value = "traceListener";

                                XmlAttribute typeAttribute = doc.CreateAttribute("type");
                                typeAttribute.Value = "System.Diagnostics.XmlWriterTraceListener";

                                XmlAttribute traceAttribute = doc.CreateAttribute("traceOutputOptions");
                                traceAttribute.Value = "ProcessId, DateTime, Callstack";

                                XmlAttribute initializeDataAttribute = doc.CreateAttribute("initializeData");
                                initializeDataAttribute.Value = "Traces.svclog";

                                sorcNode.SetAttributeNode(xmlNameAttribute);
                                sorcNode.SetAttributeNode(typeAttribute);
                                sorcNode.SetAttributeNode(traceAttribute);
                                sorcNode.SetAttributeNode(initializeDataAttribute);
                                listner.ParentNode.AppendChild(sorcNode);

                                foreach (XmlNode node in webConfigData.ChildNodes)
                                    if (node.Name == "sources")
                                    {
                                        node.AppendChild(source);
                                    }
                                isConfigNeedsToAdd = true;
                            }
                        }
                    }
                    else
                    {
                        //Add listner If listner tag not available in service.model source tag
                        var sorcNode = doc.CreateNode("element", "listeners", "");

                        sorcNode.InnerXml = innerXML;

                        source.AppendChild(sorcNode);


                        foreach (XmlNode node in webConfigData.ChildNodes)
                            if (node.Name == "sources")
                            {
                                node.AppendChild(source);
                            }
                        isConfigNeedsToAdd = true;

                    }
                    break;
                }
            }

        }

        public static XmlNodeList ChekNAddSourceInConfigServiceModel(XmlDocument doc, XmlElement webConfigData, XmlNodeList sourceAttr, string innerXML, ref bool isConfigNeedsToAdd)
        {
            //  <source name="System.ServiceModel"
            //        switchValue="Information, ActivityTracing"
            //        propagateActivity="true">
            //  <listeners>
            //    <add name="traceListener"
            //        type="System.Diagnostics.XmlWriterTraceListener"
            //         traceOutputOptions="DateTime, Timestamp, ProcessId, ThreadId, Callstack"
            //        initializeData="Traces.svclog"  />
            //  </listeners>
            //</source>
            XmlNodeList sourceNodes = null;

            if (sourceAttr != null && sourceAttr.Count > 0)
            {
                bool isConfigAdded = false;

                foreach (XmlNode item in sourceAttr[0])
                {
                    if (item.Attributes.GetNamedItem("name").Value == "System.ServiceModel")
                    {
                        sourceNodes = sourceAttr;
                        isConfigAdded = true;
                    }
                }

                if (!isConfigAdded)
                {
                    isConfigNeedsToAdd = true;
                    XmlElement sorcNode = doc.CreateElement("source");

                    XmlAttribute xmlNameAttribute = doc.CreateAttribute("name");
                    xmlNameAttribute.Value = "System.ServiceModel";

                    XmlAttribute xmlswitchValueAttribute = doc.CreateAttribute("switchValue");
                    xmlswitchValueAttribute.Value = "Information, ActivityTracing";

                    XmlAttribute xmlpropagateActivityAttribute = doc.CreateAttribute("propagateActivity");
                    xmlpropagateActivityAttribute.Value = "true";

                    sorcNode.SetAttributeNode(xmlNameAttribute);
                    sorcNode.SetAttributeNode(xmlswitchValueAttribute);
                    sorcNode.SetAttributeNode(xmlpropagateActivityAttribute);

                    sourceAttr[0].PrependChild(sorcNode);

                    sourceNodes = sourceAttr;


                }
            }
            else
            {
                var sorcNode = doc.CreateNode("element", "sources", "");
                sorcNode.InnerXml = innerXML;
                webConfigData.AppendChild(sorcNode);
                isConfigNeedsToAdd = true;
                sourceNodes = sorcNode.ChildNodes;
            }
            return sourceNodes;
        }

        public static void AddNewSystemDiagnstcs(XmlDocument doc, string innerXml)
        {
            var sorcNode = doc.CreateNode("element", "system.diagnostics", "");
            sorcNode.InnerXml = innerXml;
            doc.LastChild.AppendChild(sorcNode);
        }

        public static void ChekNAddTraceInConfig(XmlDocument doc, XmlElement webConfigData, XmlNodeList traceAttr, string innerXML, ref bool isConfigNeedsToAdd)
        {
            if (traceAttr != null && traceAttr.Count > 0)
            {
                foreach (XmlNode traceIteminConfig in traceAttr)
                {
                    if (traceIteminConfig.ParentNode.Name.ToLower() == "system.diagnostics".ToLower())
                    {
                        if (traceIteminConfig.Attributes.GetNamedItem("autoflush") is null)
                        {
                            XmlAttribute xmlNameAttribute = doc.CreateAttribute("autoflush");
                            xmlNameAttribute.Value = "true";
                            traceIteminConfig.Attributes.Append(xmlNameAttribute);
                            isConfigNeedsToAdd = true;
                        }
                        else if (traceIteminConfig.Attributes.GetNamedItem("autoflush").Value == "false")
                        {
                            traceIteminConfig.Attributes.GetNamedItem("autoflush").Value = "true";
                            isConfigNeedsToAdd = true;
                        }
                    }
                }
            }
            else
            {
                XmlElement sorcNode = doc.CreateElement("trace");

                XmlAttribute xmlNameAttribute = doc.CreateAttribute("autoflush");
                xmlNameAttribute.Value = "true";
                sorcNode.SetAttributeNode(xmlNameAttribute);
                webConfigData.PrependChild(sorcNode);
                isConfigNeedsToAdd = true;                
            }
        }
    }
}
