﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TraceConfigInjector
{
    public abstract class BaseXMLBuilder
    {
        public static void GetXMLConfigSectionByXpath(string appFullPath, out XmlDocument doc, out XmlElement webConfigData, string XpathConfiguSection)
        {            
            doc = new XmlDocument();
            doc.Load(appFullPath);

            webConfigData = (XmlElement)doc.SelectSingleNode(XpathConfiguSection);
        }
    }
}
