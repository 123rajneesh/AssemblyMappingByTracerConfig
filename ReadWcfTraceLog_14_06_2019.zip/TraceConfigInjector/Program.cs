﻿using System;
using System.Xml;

namespace TraceConfigInjector
{
    class Program
    {
        private const string XpathConfiguSection = "//configuration//system.diagnostics";

        private const string EXEConfig = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\bin\Debug\ChannelFactorySample.exe.config";
        private const string IISConfig= @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\Web\bin\Release\Publish\Web.config";
        static void Main(string[] args)
        {

            AddWCFTraceConfigInConsumerApplication(EXEConfig);
        }
        public static void AddWCFTraceConfigInConsumerApplication(string configPath)
        {

            XmlDocument doc;
            XmlElement webConfigData;

            WcfXmlNodeBuilder.GetXMLConfigSectionByXpath(configPath, out doc, out webConfigData, XpathConfiguSection);

            if (webConfigData != null)
            {
                XmlNodeList traceAttr = webConfigData.SelectNodes("//trace");
                bool isAnyChangesInConfig = false;

                WcfXmlNodeBuilder.ChekNAddTraceInConfig(doc, webConfigData, traceAttr, Resources.TraceAttr, ref isAnyChangesInConfig);

                XmlNodeList sourceAttr = webConfigData.SelectNodes("//sources");
                var SourceNodes = WcfXmlNodeBuilder.ChekNAddSourceInConfigServiceModel(doc, webConfigData, sourceAttr, Resources.Source, ref isAnyChangesInConfig);

                XmlNodeList ListenerAttr = webConfigData.SelectNodes("//listeners");
                WcfXmlNodeBuilder.CheckNAddListeners(doc, webConfigData, ListenerAttr, Resources.Listner, ref isAnyChangesInConfig, SourceNodes);



                //XmlNodeList switchesNode = webConfigData.SelectNodes("//switches");
                //WcfXmlNodeBuilder.CheckNAddSwitchesInConfig(doc, webConfigData, switchesNode, Resources.SwitchNode, ref isAnyChangesInConfig);

                if (isAnyChangesInConfig)
                {
                    doc.Save(configPath);
                }
            }
            else
            {
                WcfXmlNodeBuilder.AddNewSystemDiagnstcs(doc, Resources.ServiceModelTraceConfig);
                doc.Save(configPath);
            }
        }

    }
}
