﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            while(1==1)
            {
                ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();

                service.GetData(5);

                ServiceReference2.Service1Client service2 = new ServiceReference2.Service1Client();

                service2.GetData(5);

            }
          

        }
    }
}
