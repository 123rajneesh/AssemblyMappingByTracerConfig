﻿using System.ServiceModel;

namespace StandAloneWCF_Service
{
    [ServiceContract]
    internal interface ITestService
    {
        [OperationContract]
        string GetName(string value);
    }
}