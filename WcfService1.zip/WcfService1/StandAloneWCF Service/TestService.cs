﻿using System.ServiceModel;

namespace StandAloneWCF_Service
{

    internal class TestService : ITestService
    {
        public string GetName(string value)
        {
            throw new System.NotImplementedException();
        }
    }
}