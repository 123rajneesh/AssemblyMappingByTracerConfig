﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;

namespace StandAloneWCF_Service
{
    class Program
    {

        static void Main(string[] args)
        {
            var serviceUrl = "http://localhost:9000/TestService.svc";

            ServiceHost serviceHost = null;

            try
            {
                var uri = new Uri(serviceUrl);
                serviceHost = new ServiceHost(typeof(TestService), uri);
                var serviceMetadataBehavior = new ServiceMetadataBehavior();
                serviceHost.Description.Behaviors.Add(serviceMetadataBehavior);
                serviceHost.AddServiceEndpoint(typeof(IMetadataExchange),MetadataExchangeBindings.CreateMexHttpBinding(), "mex");
                var basicHttpBinding = new BasicHttpBinding();
                serviceHost.AddServiceEndpoint(typeof(ITestService), basicHttpBinding, serviceUrl);
                serviceHost.Open();

                Console.WriteLine("Service started... " + serviceUrl);
                Console.ReadLine();

            }

            catch (Exception ex)

            {

                serviceHost = null;

                Console.WriteLine("Error starting service" + ex.Message);

            }

            finally

            {

                if (serviceHost != null)

                    if (!(serviceHost.State == CommunicationState.Closed))

                        serviceHost.Close();

                serviceHost = null;

            }
        }
    }
}
