﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Reflection;
using System.Reflection.Emit;

namespace ConsoleAppReflection
{
    class Program
    {
        private static AssemblyBuilder ab;
        private static string moduleName;
        static void Main(string[] args)
        {
            //createInstanceofservicecontract();

            String wcfNamespace = String.Format(@"\\{0}\Root\ServiceModel", "localhost");

            ConnectionOptions connection = new ConnectionOptions();
            connection.Authentication = AuthenticationLevel.PacketPrivacy;
            ManagementScope scope = new ManagementScope(wcfNamespace, connection);
            scope.Connect();

            ObjectQuery query = new ObjectQuery("Select * From Service");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query);

            ManagementObjectCollection queryCollection = searcher.Get();
            ManagementObject[] listing = queryCollection.OfType<ManagementObject>().ToArray();

            Dictionary<int, int> portToPID = new Dictionary<int, int>();

            foreach (ManagementObject mo in queryCollection)
            {
                //each of services only have one base address in my example
                Uri baseAddress = new Uri(((Array)mo.Properties["BaseAddresses"].Value).GetValue(0).ToString());
                int pid = Int32.Parse(mo.Properties["ProcessId"].Value.ToString());
                portToPID.Add(baseAddress.Port, pid);
            }
        }

        private static void createInstanceofservicecontract()
        {
            var assem = Assembly.LoadFrom(@"F:\CrossCode\2019\WCF\Samples\WcfService1\ConsoleApp1\bin\Debug\ConsoleApp1.exe");
            var type = assem.GetType("ConsoleApp1.ServiceReference1.Service1Client");
            try
            {
                var appConfigPath = AppDomain.CurrentDomain.GetData("APP_CONFIG_FILE");

                //appConfigPath
                AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", "ConsoleApp1.exe.config");

                var wcfCientInstance = Activator.CreateInstance(type);

                AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", appConfigPath);

                //Activator.
            }
            catch (Exception ex)
            {

            }
        }

        static Assembly HandleTypeResolve(object sender, ResolveEventArgs args)
        {
            Console.WriteLine("TypeResolve event handler.");

            // Save the dynamic assembly, and then load it using its
            // display name. Return the loaded assembly.
            //
            ab.Save(moduleName);
            return Assembly.Load(ab.FullName);
        }
    }
}
